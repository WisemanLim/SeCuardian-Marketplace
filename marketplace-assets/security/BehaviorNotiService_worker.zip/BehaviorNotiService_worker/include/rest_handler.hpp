#pragma once
// BehaviorNotiService — RestHandler
// 경량 HTTP 서버 (POSIX 소켓). webhook 수신 + 상태 조회.
// POST /events  — teler/CrowdSec/Falco 이벤트 수신
// GET  /status  — 데몬 상태 조회
// GET  /alerts  — 최근 Alert 목록

#include "analysis_engine.hpp"
#include "data_storage.hpp"
#include <string>
#include <atomic>
#include <thread>
#include <functional>

namespace bns {

struct HttpRequest {
    std::string method;
    std::string path;
    std::string body;
};

struct HttpResponse {
    int         status{200};
    std::string body;
    std::string content_type{"application/json"};
};

using RequestHandler = std::function<HttpResponse(const HttpRequest&)>;

class RestHandler {
public:
    RestHandler(int port,
                AnalysisEngine& engine,
                DataStorage& storage);
    ~RestHandler();

    void start();
    void stop();

    bool is_running() const { return running_.load(); }

private:
    void serve_loop();
    void handle_client(int client_fd);
    HttpResponse dispatch(const HttpRequest& req);

    HttpResponse handle_post_events(const HttpRequest& req);
    HttpResponse handle_get_status(const HttpRequest& req);
    HttpResponse handle_get_alerts(const HttpRequest& req);

    int              port_;
    int              server_fd_{-1};
    std::atomic<bool> running_{false};
    std::thread      thread_;
    AnalysisEngine&  engine_;
    DataStorage&     storage_;
};

} // namespace bns
