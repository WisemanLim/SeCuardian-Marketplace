#pragma once
// BehaviorNotiService — LogParser
// 로그 포맷 자동 탐지 + 파싱. 지원: JSON, Nginx Combined, Syslog, teler, CrowdSec, Falco.

#include <string>
#include <optional>
#include <nlohmann/json.hpp>

namespace bns {

enum class LogFormat {
    JSON,          // {"timestamp":..., "event":...}
    NGINX_COMBINED, // 127.0.0.1 - - [date] "GET /" 200 ...
    SYSLOG,        // Jan 1 00:00:00 host daemon[pid]: msg
    TELER,         // teler JSON event
    CROWDSEC,      // CrowdSec decision JSON
    FALCO,         // Falco sidekick JSON
    UNKNOWN,
};

struct LogEvent {
    LogFormat   format;
    std::string source;        // teler|crowdsec|falco|nginx|syslog
    std::string raw;           // 원본 로그 라인
    int64_t     event_time;    // epoch seconds
    std::string src_ip;
    std::string event_type;    // brute_force|port_scan|suspicious_ua|...
    std::string severity;      // critical|high|medium|low|info
    nlohmann::json extra;      // 추가 필드 (format별 다름)
};

class LogParser {
public:
    // 자동 포맷 탐지 후 파싱
    static std::optional<LogEvent> parse(const std::string& line,
                                          const std::string& source_hint = "");

    // 포맷 탐지
    static LogFormat detect_format(const std::string& line);

private:
    static std::optional<LogEvent> parse_json(const std::string& line);
    static std::optional<LogEvent> parse_nginx(const std::string& line);
    static std::optional<LogEvent> parse_syslog(const std::string& line);
    static std::optional<LogEvent> parse_teler(const nlohmann::json& j);
    static std::optional<LogEvent> parse_crowdsec(const nlohmann::json& j);
    static std::optional<LogEvent> parse_falco(const nlohmann::json& j);
};

} // namespace bns
