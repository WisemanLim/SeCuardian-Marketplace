#pragma once
// BehaviorNotiService — DataStorage
// SQLite 기반 이벤트·Alert 이력 저장. RAII 래퍼.

#include "analysis_engine.hpp"
#include "log_parser.hpp"
#include <string>
#include <vector>
#include <memory>
#include <sqlite3.h>

namespace bns {

struct StoredAlert {
    int64_t     rowid;
    std::string id;
    std::string rule_id;
    std::string title;
    std::string severity;
    std::string src_ip;
    std::string description;
    int64_t     triggered_at;
};

class DataStorage {
public:
    explicit DataStorage(const std::string& db_path);
    ~DataStorage();

    // 스키마 초기화
    bool init();

    // Alert 저장
    bool save_alert(const Alert& alert);

    // 최근 Alert 조회 (severity 필터 선택)
    std::vector<StoredAlert> list_alerts(int limit = 100,
                                          const std::string& min_severity = "") const;

    // 이벤트 통계 (24h)
    int event_count_24h() const;

    bool is_open() const { return db_ != nullptr; }

private:
    sqlite3*    db_{nullptr};
    std::string db_path_;
};

} // namespace bns
