#pragma once
// BehaviorNotiService — AlertManager
// 탐지된 Alert를 SMTP/Slack Webhook/Wazuh UDP로 전송.

#include "analysis_engine.hpp"
#include <string>

namespace bns {

struct AlertConfig {
    // Slack Incoming Webhook
    std::string slack_webhook_url;

    // Wazuh Active Response / SIEM (JSON UDP)
    std::string wazuh_host;
    int         wazuh_port{514};     // UDP syslog 포트

    // SMTP (선택)
    std::string smtp_host;
    int         smtp_port{587};
    std::string smtp_user;
    std::string smtp_password;       // 🔴 환경변수 주입 필수
    std::string smtp_from;
    std::string smtp_to;

    // 최소 알림 심각도 (info|low|medium|high|critical)
    std::string min_severity{"high"};
};

class AlertManager {
public:
    explicit AlertManager(const AlertConfig& cfg);

    // Alert 수신 → 채널별 전송
    void send(const Alert& alert);

private:
    bool send_slack(const Alert& alert);
    bool send_wazuh(const Alert& alert);
    bool send_smtp(const Alert& alert);

    int severity_level(const std::string& sev) const;

    AlertConfig cfg_;
};

} // namespace bns
