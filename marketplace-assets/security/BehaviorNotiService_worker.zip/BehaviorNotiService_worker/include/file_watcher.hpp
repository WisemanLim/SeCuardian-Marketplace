#pragma once
// BehaviorNotiService — FileWatcher
// inotify 기반 다중 로그 디렉터리 감시. 신규 로그 라인을 콜백으로 전달.

#include <functional>
#include <string>
#include <vector>
#include <atomic>
#include <thread>
#include <unordered_map>

namespace bns {

struct LogLine {
    std::string path;      // 파일 경로
    std::string content;   // 로그 라인 내용
    int64_t     timestamp; // epoch seconds
};

using LogCallback = std::function<void(const LogLine&)>;

class FileWatcher {
public:
    explicit FileWatcher(LogCallback cb);
    ~FileWatcher();

    // 감시 디렉터리 추가 (재귀 옵션)
    bool add_watch(const std::string& dir, bool recursive = false);

    // 감시 시작 (별도 스레드)
    void start();

    // 감시 중단
    void stop();

    bool is_running() const { return running_.load(); }

private:
    void watch_loop();
    void read_new_lines(const std::string& path, std::ifstream& stream);

    LogCallback                            callback_;
    std::atomic<bool>                      running_{false};
    std::thread                            thread_;
    int                                    inotify_fd_{-1};
    std::unordered_map<int, std::string>   wd_to_path_;
    std::vector<std::string>               watched_dirs_;
};

} // namespace bns
