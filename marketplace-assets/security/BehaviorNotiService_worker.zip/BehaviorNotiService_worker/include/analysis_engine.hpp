#pragma once
// BehaviorNotiService — AnalysisEngine
// 룰 기반 + 빈도 분석으로 이상 행위 탐지. 임계값 초과 시 Alert 발행.

#include "log_parser.hpp"
#include <functional>
#include <string>
#include <unordered_map>
#include <vector>
#include <mutex>
#include <chrono>

namespace bns {

struct Alert {
    std::string id;            // UUID
    std::string rule_id;       // 트리거 룰 ID
    std::string title;
    std::string severity;      // critical|high|medium|low
    std::string src_ip;
    std::string description;
    int64_t     triggered_at;  // epoch seconds
    nlohmann::json context;    // 이벤트 샘플
};

struct Rule {
    std::string id;
    std::string name;
    std::string event_type;       // match LogEvent.event_type (* = any)
    int         threshold_count;  // 이 횟수 초과 시 알림
    int         window_seconds;   // 집계 윈도우 (초)
    std::string severity;
    std::string description;
};

using AlertCallback = std::function<void(const Alert&)>;

class AnalysisEngine {
public:
    explicit AnalysisEngine(AlertCallback cb);

    // 룰 추가 (yaml config에서 로드)
    void add_rule(const Rule& rule);

    // 로그 이벤트 처리 → 임계값 초과 시 AlertCallback 호출
    void process(const LogEvent& event);

    // 내장 기본 룰 로드 (brute_force, port_scan, suspicious_ua 등)
    void load_default_rules();

    size_t rule_count() const { return rules_.size(); }

private:
    struct Counter {
        std::vector<std::chrono::steady_clock::time_point> times;
    };

    void check_threshold(const Rule& rule, const LogEvent& event);

    AlertCallback                                      callback_;
    std::vector<Rule>                                  rules_;
    // key: rule_id + ":" + src_ip
    std::unordered_map<std::string, Counter>           counters_;
    std::mutex                                         mu_;
};

} // namespace bns
