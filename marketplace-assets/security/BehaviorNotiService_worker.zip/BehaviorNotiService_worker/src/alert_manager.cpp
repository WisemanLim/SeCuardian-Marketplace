// BehaviorNotiService — AlertManager 구현
#include "alert_manager.hpp"
#include <iostream>
#include <sstream>
#include <cstring>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <nlohmann/json.hpp>

namespace bns {

AlertManager::AlertManager(const AlertConfig& cfg) : cfg_(cfg) {}

int AlertManager::severity_level(const std::string& sev) const {
    if (sev == "critical") return 4;
    if (sev == "high")     return 3;
    if (sev == "medium")   return 2;
    if (sev == "low")      return 1;
    return 0;
}

void AlertManager::send(const Alert& alert) {
    if (severity_level(alert.severity) < severity_level(cfg_.min_severity)) return;

    if (!cfg_.slack_webhook_url.empty()) {
        if (!send_slack(alert)) {
            std::cerr << "[AlertManager] Slack 전송 실패: " << alert.id << "\n";
        }
    }
    if (!cfg_.wazuh_host.empty()) {
        if (!send_wazuh(alert)) {
            std::cerr << "[AlertManager] Wazuh 전송 실패: " << alert.id << "\n";
        }
    }
}

bool AlertManager::send_slack(const Alert& alert) {
    // Slack Incoming Webhook via POSIX socket (HTTP POST)
    nlohmann::json payload = {
        {"text", "[BNS] 🚨 " + alert.severity + ": " + alert.title},
        {"attachments", {{
            {"color", alert.severity == "critical" ? "danger" :
                      alert.severity == "high"     ? "warning" : "good"},
            {"fields", {{
                {"title", "Source IP"},  {"value", alert.src_ip},   {"short", true}
            }, {
                {"title", "Rule"},       {"value", alert.rule_id},  {"short", true}
            }, {
                {"title", "Description"}, {"value", alert.description}, {"short", false}
            }}}
        }}}
    };
    std::string body = payload.dump();
    // URL 파싱 (간단)
    std::string url = cfg_.slack_webhook_url;
    std::string host, path;
    if (url.substr(0, 8) == "https://") {
        auto slash = url.find('/', 8);
        host = url.substr(8, slash - 8);
        path = url.substr(slash);
    } else {
        std::cerr << "[AlertManager] HTTPS URL 필요: " << url << "\n";
        return false;
    }
    // NOTE: 실제 HTTPS 연결은 OpenSSL 또는 curl 필요
    // 여기서는 경고 메시지 출력 + true 반환 (구조 검증용)
    std::cout << "[AlertManager] Slack 전송 (시뮬레이션): " << host << path << "\n"
              << "  body: " << body.substr(0, 100) << "...\n";
    return true;
}

bool AlertManager::send_wazuh(const Alert& alert) {
    // Wazuh Active Response — JSON UDP syslog 전송
    nlohmann::json syslog_json = {
        {"program_name", "BehaviorNotiService"},
        {"alert_id",    alert.id},
        {"rule_id",     alert.rule_id},
        {"severity",    alert.severity},
        {"src_ip",      alert.src_ip},
        {"title",       alert.title},
        {"description", alert.description},
        {"timestamp",   alert.triggered_at}
    };
    std::string msg = "<134>" + syslog_json.dump();

    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) return false;

    struct hostent* he = gethostbyname(cfg_.wazuh_host.c_str());
    if (!he) { ::close(sock); return false; }

    struct sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port   = htons(static_cast<uint16_t>(cfg_.wazuh_port));
    memcpy(&addr.sin_addr, he->h_addr_list[0], he->h_length);

    ssize_t sent = sendto(sock, msg.c_str(), msg.size(), 0,
                         (struct sockaddr*)&addr, sizeof(addr));
    ::close(sock);
    return sent > 0;
}

} // namespace bns
