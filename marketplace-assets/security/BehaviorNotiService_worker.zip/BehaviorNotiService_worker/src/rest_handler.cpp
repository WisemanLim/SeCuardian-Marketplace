// BehaviorNotiService — RestHandler 구현 (POSIX 소켓 경량 HTTP)
#include "rest_handler.hpp"
#include <iostream>
#include <sstream>
#include <cstring>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <nlohmann/json.hpp>
#include <chrono>

namespace bns {

RestHandler::RestHandler(int port, AnalysisEngine& engine, DataStorage& storage)
    : port_(port), engine_(engine), storage_(storage) {}

RestHandler::~RestHandler() { stop(); }

void RestHandler::start() {
    if (running_.exchange(true)) return;
    thread_ = std::thread([this]{ serve_loop(); });
}

void RestHandler::stop() {
    running_.store(false);
    if (server_fd_ >= 0) { ::close(server_fd_); server_fd_ = -1; }
    if (thread_.joinable()) thread_.join();
}

void RestHandler::serve_loop() {
    server_fd_ = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd_ < 0) { running_.store(false); return; }

    int opt = 1;
    setsockopt(server_fd_, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    struct sockaddr_in addr{};
    addr.sin_family      = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port        = htons(static_cast<uint16_t>(port_));

    if (bind(server_fd_, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        std::cerr << "[RestHandler] bind 실패 (포트 " << port_ << ")\n";
        running_.store(false);
        return;
    }
    listen(server_fd_, 10);
    std::cout << "[RestHandler] HTTP 서버 시작: port " << port_ << "\n";

    while (running_.load()) {
        fd_set fds;
        FD_ZERO(&fds);
        FD_SET(server_fd_, &fds);
        struct timeval tv{1, 0};
        if (select(server_fd_ + 1, &fds, nullptr, nullptr, &tv) <= 0) continue;

        int client = accept(server_fd_, nullptr, nullptr);
        if (client >= 0) handle_client(client);
    }
}

void RestHandler::handle_client(int client_fd) {
    char buf[8192]{};
    ssize_t len = recv(client_fd, buf, sizeof(buf) - 1, 0);
    if (len <= 0) { ::close(client_fd); return; }

    // 간단 HTTP 파싱
    std::string raw(buf, len);
    HttpRequest req;
    std::istringstream ss(raw);
    ss >> req.method >> req.path;

    // Content-Length 파싱으로 body 추출
    auto pos = raw.find("\r\n\r\n");
    if (pos != std::string::npos) req.body = raw.substr(pos + 4);

    auto resp = dispatch(req);

    // HTTP 응답 전송
    std::ostringstream out;
    out << "HTTP/1.1 " << resp.status << " OK\r\n"
        << "Content-Type: " << resp.content_type << "\r\n"
        << "Content-Length: " << resp.body.size() << "\r\n"
        << "Connection: close\r\n\r\n"
        << resp.body;
    std::string raw_resp = out.str();
    send(client_fd, raw_resp.c_str(), raw_resp.size(), 0);
    ::close(client_fd);
}

HttpResponse RestHandler::dispatch(const HttpRequest& req) {
    if (req.method == "POST" && req.path == "/events")
        return handle_post_events(req);
    if (req.method == "GET"  && req.path == "/status")
        return handle_get_status(req);
    if (req.method == "GET"  && req.path == "/alerts")
        return handle_get_alerts(req);

    return {404, R"({"error":"not found"})"};
}

HttpResponse RestHandler::handle_post_events(const HttpRequest& req) {
    if (req.body.empty()) return {400, R"({"error":"empty body"})"};
    try {
        auto j = nlohmann::json::parse(req.body);
        auto events = j.is_array() ? j : nlohmann::json::array({j});
        int count = 0;
        for (auto& ev : events) {
            auto parsed = bns::LogParser::parse(ev.dump());
            if (parsed) { engine_.process(*parsed); ++count; }
        }
        return {202, nlohmann::json{{"accepted", true}, {"processed", count}}.dump()};
    } catch (...) {
        return {400, R"({"error":"invalid JSON"})"};
    }
}

HttpResponse RestHandler::handle_get_status(const HttpRequest&) {
    auto now = static_cast<int64_t>(
        std::chrono::system_clock::now().time_since_epoch().count() / 1'000'000'000LL);
    nlohmann::json j = {
        {"status",        "running"},
        {"version",       "1.0.0"},
        {"timestamp",     now},
        {"rules_loaded",  engine_.rule_count()},
        {"alerts_24h",    storage_.event_count_24h()},
        {"db_open",       storage_.is_open()},
    };
    return {200, j.dump()};
}

HttpResponse RestHandler::handle_get_alerts(const HttpRequest&) {
    auto alerts = storage_.list_alerts(50);
    nlohmann::json arr = nlohmann::json::array();
    for (auto& a : alerts) {
        arr.push_back({
            {"id",          a.id},
            {"rule_id",     a.rule_id},
            {"title",       a.title},
            {"severity",    a.severity},
            {"src_ip",      a.src_ip},
            {"description", a.description},
            {"triggered_at",a.triggered_at},
        });
    }
    return {200, nlohmann::json{{"total", alerts.size()}, {"alerts", arr}}.dump()};
}

} // namespace bns
