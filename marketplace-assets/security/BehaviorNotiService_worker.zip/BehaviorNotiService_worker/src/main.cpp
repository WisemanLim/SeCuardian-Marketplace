// BehaviorNotiService — E16 T16-1
// 행위 기반 보안 알림 서비스 (C++17 데몬)
// License: Apache-2.0  Project: SeCuardian 자체 개발
//
// Usage:
//   behavior_noti [--config <path>] [--port <8300>] [--db-path <path>]
//   behavior_noti --help

#include "file_watcher.hpp"
#include "log_parser.hpp"
#include "analysis_engine.hpp"
#include "alert_manager.hpp"
#include "data_storage.hpp"
#include "rest_handler.hpp"

#include <yaml-cpp/yaml.h>
#include <nlohmann/json.hpp>

#include <csignal>
#include <atomic>
#include <iostream>
#include <string>
#include <filesystem>

namespace {

std::atomic<bool> g_running{true};

void signal_handler(int sig) {
    std::cerr << "\n[BNS] 시그널 " << sig << " 수신 — 종료 중...\n";
    g_running.store(false);
}

struct Config {
    // 감시 디렉터리
    std::vector<std::string> watch_dirs{"/var/log"};
    // REST 서버 포트
    int port{8300};
    // SQLite DB 경로
    std::string db_path{"/var/lib/bns/bns.db"};
    // Alert 설정
    bns::AlertConfig alert;
};

Config load_config(const std::string& path) {
    Config cfg;
    if (path.empty() || !std::filesystem::exists(path)) {
        return cfg;
    }
    try {
        auto node = YAML::LoadFile(path);
        if (auto wd = node["watch_dirs"]) {
            cfg.watch_dirs.clear();
            for (auto d : wd) cfg.watch_dirs.push_back(d.as<std::string>());
        }
        if (auto p = node["port"])       cfg.port    = p.as<int>();
        if (auto d = node["db_path"])    cfg.db_path = d.as<std::string>();
        if (auto s = node["slack_webhook_url"])
            cfg.alert.slack_webhook_url = s.as<std::string>();
        if (auto w = node["wazuh_host"]) cfg.alert.wazuh_host = w.as<std::string>();
        if (auto w = node["wazuh_port"]) cfg.alert.wazuh_port = w.as<int>();
        if (auto m = node["min_severity"]) cfg.alert.min_severity = m.as<std::string>();
    } catch (const std::exception& e) {
        std::cerr << "[BNS] 설정 파일 파싱 오류: " << e.what() << "\n";
    }
    return cfg;
}

} // namespace

int main(int argc, char* argv[]) {
    std::string config_path;
    int port = 0;
    std::string db_path;

    // 간단 인수 파싱
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if ((arg == "--config" || arg == "-c") && i + 1 < argc)
            config_path = argv[++i];
        else if (arg == "--port" && i + 1 < argc)
            port = std::stoi(argv[++i]);
        else if (arg == "--db-path" && i + 1 < argc)
            db_path = argv[++i];
        else if (arg == "--help" || arg == "-h") {
            std::cout << "Usage: behavior_noti [--config path] [--port 8300] [--db-path path]\n";
            return 0;
        }
    }

    // 설정 로드
    auto cfg = load_config(config_path.empty()
        ? std::string("/etc/bns/behavior_noti.yaml")
        : config_path);
    if (port > 0)      cfg.port    = port;
    if (!db_path.empty()) cfg.db_path = db_path;

    std::cout << "[BNS] BehaviorNotiService v1.0.0 시작\n";
    std::cout << "[BNS] 포트: " << cfg.port << " | DB: " << cfg.db_path << "\n";

    // 시그널 핸들러
    std::signal(SIGINT,  signal_handler);
    std::signal(SIGTERM, signal_handler);

    // 컴포넌트 초기화
    bns::DataStorage storage(cfg.db_path);
    if (!storage.init()) {
        std::cerr << "[BNS] DataStorage 초기화 실패: " << cfg.db_path << "\n";
        return 1;
    }

    bns::AlertManager alert_mgr(cfg.alert);

    bns::AnalysisEngine engine([&](const bns::Alert& alert) {
        std::cout << "[BNS] ALERT [" << alert.severity << "] "
                  << alert.title << " from " << alert.src_ip << "\n";
        storage.save_alert(alert);
        alert_mgr.send(alert);
    });
    engine.load_default_rules();

    bns::RestHandler rest_server(cfg.port, engine, storage);
    rest_server.start();

    bns::FileWatcher watcher([&](const bns::LogLine& line) {
        auto event = bns::LogParser::parse(line.content, line.path);
        if (event) engine.process(*event);
    });

    for (const auto& dir : cfg.watch_dirs) {
        if (!watcher.add_watch(dir)) {
            std::cerr << "[BNS] 감시 디렉터리 추가 실패: " << dir << "\n";
        } else {
            std::cout << "[BNS] 감시: " << dir << "\n";
        }
    }
    watcher.start();

    std::cout << "[BNS] 준비 완료 — REST: http://0.0.0.0:" << cfg.port << "\n";

    // 메인 루프
    while (g_running.load()) {
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }

    watcher.stop();
    rest_server.stop();
    std::cout << "[BNS] 종료 완료.\n";
    return 0;
}
