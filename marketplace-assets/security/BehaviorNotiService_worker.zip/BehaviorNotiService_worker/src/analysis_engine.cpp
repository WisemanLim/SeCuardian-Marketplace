// BehaviorNotiService — AnalysisEngine 구현
#include "analysis_engine.hpp"
#include <sstream>
#include <algorithm>
#include <random>
#include <chrono>

namespace bns {

namespace {
std::string make_uuid() {
    // 간단 UUID v4 생성 (외부 라이브러리 불필요)
    std::random_device rd;
    std::mt19937_64 gen(rd());
    std::uniform_int_distribution<uint64_t> dis;
    uint64_t hi = dis(gen), lo = dis(gen);
    hi = (hi & 0xFFFFFFFFFFFF0FFFull) | 0x0000000000004000ull;
    lo = (lo & 0x3FFFFFFFFFFFFFFFull) | 0x8000000000000000ull;
    char buf[37];
    snprintf(buf, sizeof(buf),
        "%08x-%04x-%04x-%04x-%012llx",
        (uint32_t)(hi >> 32), (uint16_t)(hi >> 16),
        (uint16_t)(hi), (uint16_t)(lo >> 48),
        (unsigned long long)(lo & 0x0000FFFFFFFFFFFFull));
    return buf;
}
} // namespace

AnalysisEngine::AnalysisEngine(AlertCallback cb) : callback_(std::move(cb)) {}

void AnalysisEngine::add_rule(const Rule& rule) {
    std::lock_guard<std::mutex> lock(mu_);
    rules_.push_back(rule);
}

void AnalysisEngine::load_default_rules() {
    // 브루트포스 탐지 — 60초 내 10회 이상 인증 실패
    add_rule({"R001", "BruteForce 탐지",    "auth_failure",    10, 60,  "high",
              "단시간 내 반복 인증 실패 — 브루트포스 의심"});
    // 포트 스캔 탐지 — 10초 내 20회 이상 연결 시도
    add_rule({"R002", "Port Scan 탐지",     "port_scan",       20, 10,  "high",
              "짧은 시간 내 다수 포트 연결 시도 — 포트 스캔 의심"});
    // 비정상 User-Agent — 60초 내 5회 이상
    add_rule({"R003", "악성 UA 탐지",       "suspicious_ua",    5, 60,  "medium",
              "알려진 악성 User-Agent 반복 탐지"});
    // SQL 인젝션 시도 — 60초 내 3회 이상
    add_rule({"R004", "SQLi 시도 탐지",     "sql_injection",    3, 60,  "critical",
              "SQL 인젝션 패턴 반복 탐지"});
    // XSS 시도 — 60초 내 3회 이상
    add_rule({"R005", "XSS 시도 탐지",      "xss",              3, 60,  "high",
              "XSS 패턴 반복 탐지"});
    // CrowdSec 차단 IP 재접속 — 즉시 알림 (1회)
    add_rule({"R006", "차단 IP 재접속",     "blocked_ip",       1, 300, "critical",
              "CrowdSec 차단 IP가 재접속 시도"});
    // Falco 컨테이너 이상 행위 — 즉시 알림
    add_rule({"R007", "컨테이너 이상 행위", "runtime_anomaly",  1, 60,  "critical",
              "Falco 런타임 이상 행위 탐지"});
}

void AnalysisEngine::process(const LogEvent& event) {
    std::lock_guard<std::mutex> lock(mu_);
    for (const auto& rule : rules_) {
        if (rule.event_type == "*" || rule.event_type == event.event_type) {
            check_threshold(rule, event);
        }
    }
}

void AnalysisEngine::check_threshold(const Rule& rule, const LogEvent& event) {
    auto now = std::chrono::steady_clock::now();
    std::string key = rule.id + ":" + event.src_ip;
    auto& counter = counters_[key];

    // 윈도우 밖 항목 제거
    auto window = std::chrono::seconds(rule.window_seconds);
    counter.times.erase(
        std::remove_if(counter.times.begin(), counter.times.end(),
            [&](const auto& t) { return (now - t) > window; }),
        counter.times.end());

    counter.times.push_back(now);

    if ((int)counter.times.size() >= rule.threshold_count) {
        counter.times.clear(); // 알림 후 카운터 리셋 (중복 알림 방지)

        Alert alert;
        alert.id          = make_uuid();
        alert.rule_id     = rule.id;
        alert.title       = rule.name;
        alert.severity    = rule.severity;
        alert.src_ip      = event.src_ip;
        alert.description = rule.description;
        alert.triggered_at = event.event_time;
        alert.context     = event.extra;
        alert.context["event_type"] = event.event_type;
        alert.context["source"]     = event.source;
        alert.context["raw"]        = event.raw.substr(0, 200);

        if (callback_) callback_(alert);
    }
}

} // namespace bns
