// BehaviorNotiService — FileWatcher 구현 (inotify, Linux)
#include "file_watcher.hpp"
#include <fstream>
#include <iostream>
#include <unistd.h>
#include <sys/inotify.h>
#include <filesystem>

namespace bns {

FileWatcher::FileWatcher(LogCallback cb) : callback_(std::move(cb)) {
    inotify_fd_ = inotify_init1(IN_NONBLOCK);
    if (inotify_fd_ < 0) {
        std::cerr << "[FileWatcher] inotify_init 실패\n";
    }
}

FileWatcher::~FileWatcher() {
    stop();
    if (inotify_fd_ >= 0) ::close(inotify_fd_);
}

bool FileWatcher::add_watch(const std::string& dir, bool recursive) {
    namespace fs = std::filesystem;
    if (!fs::exists(dir)) return false;

    auto add_dir = [&](const std::string& d) {
        int wd = inotify_add_watch(inotify_fd_, d.c_str(),
                                   IN_MODIFY | IN_CREATE | IN_MOVED_TO);
        if (wd >= 0) {
            wd_to_path_[wd] = d;
            watched_dirs_.push_back(d);
        }
    };

    add_dir(dir);
    if (recursive) {
        try {
            for (auto& entry : fs::recursive_directory_iterator(dir)) {
                if (entry.is_directory()) add_dir(entry.path().string());
            }
        } catch (...) {}
    }
    return true;
}

void FileWatcher::start() {
    if (running_.exchange(true)) return;
    thread_ = std::thread([this]{ watch_loop(); });
}

void FileWatcher::stop() {
    running_.store(false);
    if (thread_.joinable()) thread_.join();
}

void FileWatcher::watch_loop() {
    constexpr int BUF_LEN = 4096;
    char buf[BUF_LEN] __attribute__((aligned(__alignof__(inotify_event))));

    // 기존 파일 끝으로 이동 (중복 읽기 방지)
    std::unordered_map<std::string, std::ifstream> file_streams;

    while (running_.load()) {
        fd_set fds;
        FD_ZERO(&fds);
        FD_SET(inotify_fd_, &fds);
        struct timeval tv{1, 0};
        int ret = select(inotify_fd_ + 1, &fds, nullptr, nullptr, &tv);
        if (ret <= 0) continue;

        ssize_t len = read(inotify_fd_, buf, BUF_LEN);
        if (len <= 0) continue;

        for (char* ptr = buf; ptr < buf + len; ) {
            auto* event = reinterpret_cast<inotify_event*>(ptr);
            if (event->len > 0) {
                auto it = wd_to_path_.find(event->wd);
                if (it != wd_to_path_.end()) {
                    std::string filepath = it->second + "/" + event->name;
                    auto& stream = file_streams[filepath];
                    if (!stream.is_open()) {
                        stream.open(filepath);
                        stream.seekg(0, std::ios::end); // 기존 내용 건너뜀
                    }
                    read_new_lines(filepath, stream);
                }
            }
            ptr += sizeof(inotify_event) + event->len;
        }
    }
}

void FileWatcher::read_new_lines(const std::string& path, std::ifstream& stream) {
    std::string line;
    while (std::getline(stream, line)) {
        if (!line.empty()) {
            LogLine ll;
            ll.path = path;
            ll.content = line;
            ll.timestamp = static_cast<int64_t>(
                std::chrono::system_clock::now().time_since_epoch().count() / 1'000'000'000LL);
            if (callback_) callback_(ll);
        }
    }
    stream.clear(); // EOF 플래그 초기화
}

} // namespace bns
