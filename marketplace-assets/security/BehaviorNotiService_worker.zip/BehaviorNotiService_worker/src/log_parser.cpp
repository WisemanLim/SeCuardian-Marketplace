// BehaviorNotiService — LogParser 구현
#include "log_parser.hpp"
#include <regex>
#include <chrono>

namespace bns {

LogFormat LogParser::detect_format(const std::string& line) {
    if (line.empty()) return LogFormat::UNKNOWN;
    if (line.front() == '{') {
        try {
            auto j = nlohmann::json::parse(line);
            if (j.contains("category") || j.contains("teler"))  return LogFormat::TELER;
            if (j.contains("decisions") || j.contains("origin")) return LogFormat::CROWDSEC;
            if (j.contains("rule") && j.contains("output"))      return LogFormat::FALCO;
            return LogFormat::JSON;
        } catch (...) {}
    }
    // Nginx Combined: 127.0.0.1 - - [date] "METHOD ..."
    static const std::regex nginx_re(R"(^\d+\.\d+\.\d+\.\d+ - .* \[.+\] ".+")");
    if (std::regex_search(line, nginx_re)) return LogFormat::NGINX_COMBINED;
    // Syslog: "Jan  1 00:00:00 host"
    static const std::regex syslog_re(R"(^[A-Z][a-z]{2}\s+\d+ \d{2}:\d{2}:\d{2} \S+)");
    if (std::regex_search(line, syslog_re)) return LogFormat::SYSLOG;
    return LogFormat::UNKNOWN;
}

std::optional<LogEvent> LogParser::parse(const std::string& line,
                                          const std::string& source_hint) {
    if (line.empty()) return std::nullopt;
    auto fmt = detect_format(line);
    switch (fmt) {
    case LogFormat::JSON:
    case LogFormat::TELER:
    case LogFormat::CROWDSEC:
    case LogFormat::FALCO:
        return parse_json(line);
    case LogFormat::NGINX_COMBINED:
        return parse_nginx(line);
    case LogFormat::SYSLOG:
        return parse_syslog(line);
    default:
        return std::nullopt;
    }
}

std::optional<LogEvent> LogParser::parse_json(const std::string& line) {
    try {
        auto j = nlohmann::json::parse(line);

        LogEvent ev;
        ev.raw        = line;
        ev.extra      = j;
        ev.event_time = static_cast<int64_t>(
            std::chrono::system_clock::now().time_since_epoch().count() / 1'000'000'000LL);

        // Teler 이벤트
        if (j.contains("category")) {
            ev.format     = LogFormat::TELER;
            ev.source     = "teler";
            ev.event_type = j.value("category", "unknown");
            ev.src_ip     = j.value("remote_addr", "");
            ev.severity   = "high";
            return ev;
        }
        // CrowdSec decision
        if (j.contains("decisions")) {
            ev.format     = LogFormat::CROWDSEC;
            ev.source     = "crowdsec";
            ev.event_type = "blocked_ip";
            ev.src_ip     = j.contains("decisions") && j["decisions"].is_array() &&
                            !j["decisions"].empty()
                            ? j["decisions"][0].value("value", "") : "";
            ev.severity   = "critical";
            return ev;
        }
        // Falco sidekick
        if (j.contains("rule") && j.contains("output")) {
            ev.format     = LogFormat::FALCO;
            ev.source     = "falco";
            ev.event_type = "runtime_anomaly";
            ev.severity   = j.value("priority", "warning") == "Critical" ? "critical" : "high";
            ev.src_ip     = "";
            return ev;
        }
        // Generic JSON
        ev.format     = LogFormat::JSON;
        ev.source     = "generic";
        ev.event_type = j.value("event_type", j.value("type", "generic"));
        ev.src_ip     = j.value("src_ip", j.value("remote_addr", j.value("ip", "")));
        ev.severity   = j.value("severity", "info");
        return ev;

    } catch (...) {
        return std::nullopt;
    }
}

std::optional<LogEvent> LogParser::parse_nginx(const std::string& line) {
    // 127.0.0.1 - user [01/Jan/2024:00:00:00 +0000] "GET /path HTTP/1.1" 200 1234
    static const std::regex re(
        R"(^(\S+) \S+ \S+ \[([^\]]+)\] "(\S+) ([^"]+)" (\d+) (\S+))");
    std::smatch m;
    if (!std::regex_search(line, m, re)) return std::nullopt;

    LogEvent ev;
    ev.format     = LogFormat::NGINX_COMBINED;
    ev.source     = "nginx";
    ev.raw        = line;
    ev.src_ip     = m[1];
    ev.event_time = static_cast<int64_t>(
        std::chrono::system_clock::now().time_since_epoch().count() / 1'000'000'000LL);
    ev.extra["method"]  = m[3].str();
    ev.extra["path"]    = m[4].str();
    ev.extra["status"]  = std::stoi(m[5].str());

    // 간단한 이상 탐지 패턴
    const std::string path = m[4].str();
    if (path.find("UNION SELECT") != std::string::npos ||
        path.find("1=1") != std::string::npos) {
        ev.event_type = "sql_injection";
        ev.severity   = "critical";
    } else if (path.find("<script>") != std::string::npos) {
        ev.event_type = "xss";
        ev.severity   = "high";
    } else if (std::stoi(m[5].str()) == 401) {
        ev.event_type = "auth_failure";
        ev.severity   = "medium";
    } else {
        ev.event_type = "http_request";
        ev.severity   = "info";
    }
    return ev;
}

std::optional<LogEvent> LogParser::parse_syslog(const std::string& line) {
    LogEvent ev;
    ev.format     = LogFormat::SYSLOG;
    ev.source     = "syslog";
    ev.raw        = line;
    ev.event_time = static_cast<int64_t>(
        std::chrono::system_clock::now().time_since_epoch().count() / 1'000'000'000LL);
    ev.extra["raw"] = line;

    if (line.find("Failed password") != std::string::npos ||
        line.find("authentication failure") != std::string::npos) {
        ev.event_type = "auth_failure";
        ev.severity   = "medium";
    } else if (line.find("Accepted password") != std::string::npos) {
        ev.event_type = "auth_success";
        ev.severity   = "info";
    } else {
        ev.event_type = "syslog_event";
        ev.severity   = "info";
    }
    return ev;
}

} // namespace bns
