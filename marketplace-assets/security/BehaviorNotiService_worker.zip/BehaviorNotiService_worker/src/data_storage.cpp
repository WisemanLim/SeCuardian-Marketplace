// BehaviorNotiService — DataStorage 구현 (SQLite)
#include "data_storage.hpp"
#include <iostream>
#include <filesystem>
#include <nlohmann/json.hpp>

namespace bns {

DataStorage::DataStorage(const std::string& db_path) : db_path_(db_path) {}

DataStorage::~DataStorage() {
    if (db_) sqlite3_close(db_);
}

bool DataStorage::init() {
    namespace fs = std::filesystem;
    // DB 디렉터리 생성
    auto parent = fs::path(db_path_).parent_path();
    if (!parent.empty() && !fs::exists(parent)) {
        std::error_code ec;
        fs::create_directories(parent, ec);
        if (ec) {
            std::cerr << "[DataStorage] 디렉터리 생성 실패: " << ec.message() << "\n";
            return false;
        }
    }

    if (sqlite3_open(db_path_.c_str(), &db_) != SQLITE_OK) {
        std::cerr << "[DataStorage] DB 열기 실패: " << sqlite3_errmsg(db_) << "\n";
        return false;
    }

    const char* schema = R"SQL(
        CREATE TABLE IF NOT EXISTS alerts (
            rowid       INTEGER PRIMARY KEY AUTOINCREMENT,
            id          TEXT NOT NULL UNIQUE,
            rule_id     TEXT NOT NULL,
            title       TEXT NOT NULL,
            severity    TEXT NOT NULL,
            src_ip      TEXT,
            description TEXT,
            context     TEXT,
            triggered_at INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_alerts_triggered ON alerts(triggered_at DESC);
        CREATE INDEX IF NOT EXISTS idx_alerts_severity  ON alerts(severity);
    )SQL";

    char* err = nullptr;
    if (sqlite3_exec(db_, schema, nullptr, nullptr, &err) != SQLITE_OK) {
        std::cerr << "[DataStorage] 스키마 생성 실패: " << err << "\n";
        sqlite3_free(err);
        return false;
    }
    return true;
}

bool DataStorage::save_alert(const Alert& alert) {
    if (!db_) return false;
    const char* sql = R"SQL(
        INSERT OR IGNORE INTO alerts
            (id, rule_id, title, severity, src_ip, description, context, triggered_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    )SQL";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) return false;

    std::string ctx = alert.context.dump();
    sqlite3_bind_text(stmt, 1, alert.id.c_str(),          -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, alert.rule_id.c_str(),      -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 3, alert.title.c_str(),        -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 4, alert.severity.c_str(),     -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 5, alert.src_ip.c_str(),       -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 6, alert.description.c_str(),  -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 7, ctx.c_str(),                -1, SQLITE_STATIC);
    sqlite3_bind_int64(stmt, 8, alert.triggered_at);

    bool ok = sqlite3_step(stmt) == SQLITE_DONE;
    sqlite3_finalize(stmt);
    return ok;
}

std::vector<StoredAlert> DataStorage::list_alerts(int limit,
                                                   const std::string& min_severity) const {
    if (!db_) return {};

    std::string sql = "SELECT rowid, id, rule_id, title, severity, src_ip, description, triggered_at "
                      "FROM alerts ORDER BY triggered_at DESC LIMIT ?";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK)
        return {};
    sqlite3_bind_int(stmt, 1, limit);

    std::vector<StoredAlert> results;
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        StoredAlert sa;
        sa.rowid       = sqlite3_column_int64(stmt, 0);
        auto get_text  = [&](int col) -> std::string {
            auto* p = reinterpret_cast<const char*>(sqlite3_column_text(stmt, col));
            return p ? p : "";
        };
        sa.id          = get_text(1);
        sa.rule_id     = get_text(2);
        sa.title       = get_text(3);
        sa.severity    = get_text(4);
        sa.src_ip      = get_text(5);
        sa.description = get_text(6);
        sa.triggered_at = sqlite3_column_int64(stmt, 7);
        results.push_back(sa);
    }
    sqlite3_finalize(stmt);
    return results;
}

int DataStorage::event_count_24h() const {
    if (!db_) return 0;
    int64_t since = static_cast<int64_t>(
        std::chrono::system_clock::now().time_since_epoch().count() / 1'000'000'000LL) - 86400;
    const char* sql = "SELECT COUNT(*) FROM alerts WHERE triggered_at >= ?";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) return 0;
    sqlite3_bind_int64(stmt, 1, since);
    int count = sqlite3_step(stmt) == SQLITE_ROW ? sqlite3_column_int(stmt, 0) : 0;
    sqlite3_finalize(stmt);
    return count;
}

} // namespace bns
