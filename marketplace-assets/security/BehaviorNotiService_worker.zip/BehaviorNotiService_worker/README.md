# BehaviorNotiService_worker — 행위 기반 알림 Worker (C++)

SeCuardian `behavior-noti` 에이전트의 실작업 worker 입니다. 감시 대상 호스트(서버·PC·Edge
디바이스)에 설치되어 로그(`/var/log`)를 감시하고 이상 행위 이벤트를 SeCuardian 웹훅
(`POST /api/behavior/events`)·Slack·Wazuh 로 전송합니다.
This is the worker for the SeCuardian `behavior-noti` agent. Install it on each monitored
host; it watches host logs and pushes anomaly events to the SeCuardian webhook
(`POST /api/behavior/events`), Slack, or Wazuh.

- 버전 / Version: `VERSION` 파일 참조 (semver)
- REST 포트 / REST port: `8300`
- 배포 패키지 / Package: `BehaviorNotiService_worker.zip` — `make worker-package` (repo 루트)로 재생성

## 빠른 시작 / Quick start

```bash
# Docker (권장 / recommended)
docker build -t secuardian/behavior-noti:1.0.0 .
docker run -d --name behavior-noti --restart unless-stopped \
  -p 127.0.0.1:8300:8300 \
  -v behavior_db:/var/lib/bns \
  -v /var/log:/var/log/host:ro \
  -v "$PWD/config/behavior_noti.yaml:/etc/bns/behavior_noti.yaml:ro" \
  secuardian/behavior-noti:1.0.0

# SeCuardian 저장소가 있으면 / from the repo root
make behavior-build && make behavior-up

# 네이티브 빌드 / native build (CMake 3.20+, g++ C++17, libsqlite3-dev, libyaml-cpp-dev)
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build --parallel
```

## 설정 / Configuration

- `config/behavior_noti.yaml` — 탐지 룰·웹훅 대상·HMAC 서명
- 환경변수 / env: `SLACK_WEBHOOK_URL`(선택), `WAZUH_HOST`/`WAZUH_PORT`(선택, 기본 514)
- 서버 측 / server side: `BEHAVIOR_NOTI_ENABLED=true`,
  `BEHAVIOR_NOTI_URL=http://host.docker.internal:8300`

상세 설치·운영 가이드는 에이전트에 내장된 `behavior-noti-worker-guide.md`
(`addon-agents/zip/behavior-noti/` 또는 배포 후 `addon-agents/deployed/behavior-noti/`)를 참조하세요.
