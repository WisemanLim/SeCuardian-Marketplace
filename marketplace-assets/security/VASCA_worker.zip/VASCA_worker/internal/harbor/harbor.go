// Package harbor — Harbor Registry API 클라이언트
// VASCA v2 E07-v2 T07-4
// Harbor v2 API: 프로젝트/레포지터리/태그 조회 + 취약점 스캔 트리거
package harbor

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"
)

// Client — Harbor API v2 클라이언트
type Client struct {
	BaseURL  string
	Username string
	Password string
	http     *http.Client
}

// NewClient — Harbor 클라이언트 생성
func NewClient(baseURL, username, password string) *Client {
	return &Client{
		BaseURL:  baseURL,
		Username: username,
		Password: password,
		http: &http.Client{
			Timeout: 30 * time.Second,
		},
	}
}

// Repository — Harbor 레포지터리
type Repository struct {
	Name          string    `json:"name"`
	ProjectID     int       `json:"project_id"`
	ArtifactCount int       `json:"artifact_count"`
	UpdateTime    time.Time `json:"update_time"`
}

// Artifact — Harbor 아티팩트(이미지 태그)
type Artifact struct {
	Digest      string    `json:"digest"`
	Tags        []Tag     `json:"tags"`
	Size        int64     `json:"size"`
	PushTime    time.Time `json:"push_time"`
	ScanOverview map[string]ScanSummary `json:"scan_overview"`
}

// Tag — 이미지 태그
type Tag struct {
	Name string `json:"name"`
}

// ScanSummary — Harbor 취약점 스캔 결과 요약
type ScanSummary struct {
	ScanStatus  string    `json:"scan_status"`
	Severity    string    `json:"severity"`
	StartTime   time.Time `json:"start_time"`
	EndTime     time.Time `json:"end_time"`
	Summary     *VulnSummary `json:"summary"`
}

// VulnSummary — 심각도별 취약점 수
type VulnSummary struct {
	Total    int `json:"total"`
	Critical int `json:"critical"`
	High     int `json:"high"`
	Medium   int `json:"medium"`
	Low      int `json:"low"`
}

// ListRepositories — 프로젝트 내 레포지터리 목록
func (c *Client) ListRepositories(ctx context.Context, project string) ([]Repository, error) {
	path := fmt.Sprintf("/api/v2.0/projects/%s/repositories?page_size=100", project)
	var repos []Repository
	if err := c.get(ctx, path, &repos); err != nil {
		return nil, err
	}
	return repos, nil
}

// ListArtifacts — 레포지터리 내 아티팩트 목록
func (c *Client) ListArtifacts(ctx context.Context, project, repo string) ([]Artifact, error) {
	path := fmt.Sprintf("/api/v2.0/projects/%s/repositories/%s/artifacts?with_scan_overview=true&page_size=20",
		project, repo)
	var artifacts []Artifact
	if err := c.get(ctx, path, &artifacts); err != nil {
		return nil, err
	}
	return artifacts, nil
}

// TriggerScan — Harbor 취약점 스캔 트리거
func (c *Client) TriggerScan(ctx context.Context, project, repo, reference string) error {
	path := fmt.Sprintf("/api/v2.0/projects/%s/repositories/%s/artifacts/%s/scan",
		project, repo, reference)
	req, err := http.NewRequestWithContext(ctx, http.MethodPost,
		c.BaseURL+path, nil)
	if err != nil {
		return err
	}
	req.SetBasicAuth(c.Username, c.Password)

	resp, err := c.http.Do(req)
	if err != nil {
		return fmt.Errorf("harbor scan trigger: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusAccepted && resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		return fmt.Errorf("harbor scan trigger failed: %d — %s", resp.StatusCode, body)
	}
	return nil
}

// Health — Harbor 헬스체크
func (c *Client) Health(ctx context.Context) (map[string]any, error) {
	var result map[string]any
	if err := c.get(ctx, "/api/v2.0/health", &result); err != nil {
		return nil, err
	}
	return result, nil
}

func (c *Client) get(ctx context.Context, path string, out any) error {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, c.BaseURL+path, nil)
	if err != nil {
		return err
	}
	req.SetBasicAuth(c.Username, c.Password)
	req.Header.Set("Accept", "application/json")

	resp, err := c.http.Do(req)
	if err != nil {
		return fmt.Errorf("harbor GET %s: %w", path, err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		return fmt.Errorf("harbor %d: %s", resp.StatusCode, body)
	}

	return json.NewDecoder(resp.Body).Decode(out)
}
