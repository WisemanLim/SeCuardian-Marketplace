// Package scheduler runs periodic VASCA scans via cron.
// Source: VASCA v1 | License: Apache-2.0 | Usage: internal only
package scheduler

import (
	"context"
	"fmt"
	"log/slog"
	"os"
	"time"

	"vasca/internal/notifier"
	"vasca/internal/reporter"
	"vasca/internal/scanner"
	"vasca/internal/store"
	"vasca/pkg/cve"
)

// Config holds scheduler settings.
type Config struct {
	CronExpr string // e.g. "0 2 * * 0"  (Sun 02:00 = weekly)
	Host     string
	Format   reporter.Format
	Notify   notifier.Config
}

// RunOnce performs a single scan cycle: scan → persist → report → notify (new CVEs only).
// st may be nil; when provided, duplicate alerts are suppressed.
func RunOnce(ctx context.Context, cfg Config, st *store.Store) error {
	hostname, _ := os.Hostname()
	host := cfg.Host
	if host == "" {
		host = hostname
	}

	slog.Info("vasca: scan start", "host", host)
	result, err := scanner.ScanHost(ctx, host)
	if err != nil {
		return fmt.Errorf("scan: %w", err)
	}
	slog.Info("vasca: scan done", "summary", result.Summary())

	// Persist scan history.
	if st != nil {
		if err := st.SaveScan(ctx, result); err != nil {
			slog.Warn("vasca: store.SaveScan failed", "err", err)
		}
	}

	// Report shows all CVEs.
	if err := reporter.Print(result, cfg.Format); err != nil {
		return fmt.Errorf("report: %w", err)
	}

	// Notify only new CRITICAL/HIGH CVEs (skip already-alerted ones).
	notifyResult := filterNewCVEs(ctx, result, st)
	if notifyResult.Critical > 0 || notifyResult.High > 0 {
		if err := notifier.Send(ctx, cfg.Notify, notifyResult); err != nil {
			slog.Warn("vasca: notify failed", "err", err)
		} else if st != nil {
			for _, c := range notifyResult.CVEs {
				if c.Severity == cve.SeverityCritical || c.Severity == cve.SeverityHigh {
					_ = st.MarkAlertSent(ctx, c.ID, host)
				}
			}
		}
	}
	return nil
}

// RunScheduled loops indefinitely, running a scan on each interval tick.
// For production, prefer StartCron (cron.go) with a cron expression.
func RunScheduled(ctx context.Context, cfg Config, st *store.Store, interval time.Duration) {
	slog.Info("vasca: interval scheduler started", "interval", interval)
	for {
		select {
		case <-ctx.Done():
			return
		case <-time.After(interval):
			if err := RunOnce(ctx, cfg, st); err != nil {
				slog.Error("vasca: scan cycle error", "err", err)
			}
		}
	}
}

// filterNewCVEs returns a copy of result containing only CVEs not yet alerted.
// When st is nil, all CVEs are returned unchanged.
func filterNewCVEs(ctx context.Context, result *cve.ScanResult, st *store.Store) *cve.ScanResult {
	if st == nil {
		return result
	}

	filtered := &cve.ScanResult{
		ScanID:     result.ScanID,
		Host:       result.Host,
		StartedAt:  result.StartedAt,
		FinishedAt: result.FinishedAt,
	}

	for _, c := range result.CVEs {
		if c.Severity != cve.SeverityCritical && c.Severity != cve.SeverityHigh {
			continue
		}
		sent, err := st.IsAlertSent(ctx, c.ID, result.Host)
		if err != nil || sent {
			continue
		}
		filtered.CVEs = append(filtered.CVEs, c)
		filtered.Total++
		switch c.Severity {
		case cve.SeverityCritical:
			filtered.Critical++
		case cve.SeverityHigh:
			filtered.High++
		}
	}
	return filtered
}
