// Package scheduler — cron.go adds robfig/cron-based periodic scheduling.
// Source: VASCA v1 | License: Apache-2.0 | Usage: internal only
package scheduler

import (
	"context"
	"log/slog"
	"time"

	"github.com/robfig/cron/v3"

	"vasca/internal/store"
)

// DefaultCronExpr is Sunday 02:00 local time (weekly scan).
const DefaultCronExpr = "0 2 * * 0"

// StartCron starts a robfig/cron-based scheduler using a 5-field cron expression.
// Returns the running *cron.Cron; caller must call Stop() on shutdown.
// If expr is empty, DefaultCronExpr ("0 2 * * 0") is used.
func StartCron(ctx context.Context, expr string, cfg Config, st *store.Store) (*cron.Cron, error) {
	if expr == "" {
		expr = DefaultCronExpr
	}

	c := cron.New()
	_, err := c.AddFunc(expr, func() {
		scanCtx, cancel := context.WithTimeout(context.Background(), 15*time.Minute)
		defer cancel()
		if err := RunOnce(scanCtx, cfg, st); err != nil {
			slog.Error("vasca: cron scan error", "err", err)
		}
	})
	if err != nil {
		return nil, err
	}

	c.Start()
	slog.Info("vasca: cron scheduler started", "expr", expr)

	// Stop cron when context is cancelled.
	go func() {
		<-ctx.Done()
		c.Stop()
		slog.Info("vasca: cron scheduler stopped")
	}()

	return c, nil
}
