// Package sbom — SBOM 생성 (syft 래퍼)
// VASCA v2 E07-v2 T07-2
// syft CLI 호출 → JSON/SPDX/CycloneDX 포맷 지원
package sbom

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"os/exec"
	"strings"
	"time"
)

// Format — syft 출력 포맷
type Format string

const (
	FormatJSON      Format = "syft-json"    // syft 내부 JSON
	FormatSPDX      Format = "spdx-json"    // SPDX 2.3 JSON
	FormatCycloneDX Format = "cyclonedx-json" // CycloneDX 1.5 JSON
)

// Result — SBOM 생성 결과
type Result struct {
	Target     string    `json:"target"`
	Format     Format    `json:"format"`
	GeneratedAt time.Time `json:"generated_at"`
	PackageCount int      `json:"package_count"`
	Raw        string    `json:"raw"` // syft 출력 원문
}

// Generate — 대상(이미지/경로)에 대해 syft로 SBOM 생성
func Generate(ctx context.Context, target string, fmt Format) (*Result, error) {
	if err := checkSyft(); err != nil {
		return nil, err
	}

	args := []string{"scan", target, "-o", string(fmt), "--quiet"}
	cmd := exec.CommandContext(ctx, "syft", args...)
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr

	if err := cmd.Run(); err != nil {
		return nil, fmt_errorf("syft failed: %w\nstderr: %s", err, stderr.String())
	}

	raw := stdout.String()
	pkgCount := countPackages(raw, fmt)

	return &Result{
		Target:      target,
		Format:      fmt,
		GeneratedAt: time.Now().UTC(),
		PackageCount: pkgCount,
		Raw:         raw,
	}, nil
}

// GenerateForImage — Harbor 이미지용 SBOM (docker pull 없이 레지스트리 직접)
// target 예: registry.internal/project/image:tag
func GenerateForImage(ctx context.Context, imageRef string, fmt Format) (*Result, error) {
	return Generate(ctx, "registry:"+imageRef, fmt)
}

// checkSyft — syft 바이너리 존재 확인
func checkSyft() error {
	if _, err := exec.LookPath("syft"); err != nil {
		return fmt.Errorf("syft not found in PATH — install: curl -sSfL https://raw.githubusercontent.com/anchore/syft/main/install.sh | sh")
	}
	return nil
}

// countPackages — 패키지 수 추정 (JSON 파싱)
func countPackages(raw string, f Format) int {
	if f == FormatJSON {
		var doc struct {
			Artifacts []json.RawMessage `json:"artifacts"`
		}
		if err := json.Unmarshal([]byte(raw), &doc); err == nil {
			return len(doc.Artifacts)
		}
	}
	// 간단 휴리스틱 — "name" 키 등장 수 / 2
	return strings.Count(raw, `"name"`) / 2
}

func fmt_errorf(format string, args ...any) error {
	return fmt.Errorf(format, args...)
}
