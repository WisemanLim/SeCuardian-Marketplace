// Package reporter formats and outputs VASCA scan results.
// Source: VASCA v1 | License: Apache-2.0 | Usage: internal only
package reporter

import (
	"encoding/json"
	"fmt"
	"io"
	"os"
	"text/tabwriter"

	"vasca/pkg/cve"
)

// Format controls output style.
type Format string

const (
	FormatText Format = "text"
	FormatJSON Format = "json"
)

// Print writes scan results to stdout in the given format.
// Only CRITICAL and HIGH CVEs are shown in text mode by default.
func Print(result *cve.ScanResult, format Format) error {
	switch format {
	case FormatJSON:
		return printJSON(os.Stdout, result)
	default:
		return printText(os.Stdout, result)
	}
}

func printJSON(w io.Writer, result *cve.ScanResult) error {
	enc := json.NewEncoder(w)
	enc.SetIndent("", "  ")
	return enc.Encode(result)
}

func printText(w io.Writer, result *cve.ScanResult) error {
	fmt.Fprintf(w, "VASCA Scan Report\n")
	fmt.Fprintf(w, "  Scan ID  : %s\n", result.ScanID)
	fmt.Fprintf(w, "  Host     : %s\n", result.Host)
	fmt.Fprintf(w, "  Duration : %.1fs\n", result.DurationSec)
	fmt.Fprintf(w, "  Total    : %d  CRIT=%d HIGH=%d MED=%d LOW=%d\n\n",
		result.Total, result.Critical, result.High, result.Medium, result.Low)

	tw := tabwriter.NewWriter(w, 0, 0, 2, ' ', 0)
	fmt.Fprintln(tw, "ID\tSEVERITY\tCVSS\tPACKAGE\tVERSION\tFIXED_IN")
	for _, c := range result.CVEs {
		if c.Severity != cve.SeverityCritical && c.Severity != cve.SeverityHigh {
			continue
		}
		fmt.Fprintf(tw, "%s\t%s\t%.1f\t%s\t%s\t%s\n",
			c.ID, c.Severity, c.CVSS, c.Package, c.Version, c.FixedIn)
	}
	return tw.Flush()
}
