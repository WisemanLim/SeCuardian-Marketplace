package store_test

import (
	"context"
	"testing"
	"time"

	"vasca/internal/store"
	"vasca/pkg/cve"
)

func newTestStore(t *testing.T) *store.Store {
	t.Helper()
	st, err := store.Open(":memory:")
	if err != nil {
		t.Fatalf("store.Open: %v", err)
	}
	t.Cleanup(func() { st.Close() })
	return st
}

func sampleResult() *cve.ScanResult {
	now := time.Now().UTC().Truncate(time.Second)
	return &cve.ScanResult{
		ScanID:      "vasca-test-001",
		Host:        "testhost",
		StartedAt:   now,
		FinishedAt:  now.Add(5 * time.Second),
		DurationSec: 5.0,
		Total:       2,
		Critical:    1,
		High:        1,
		CVEs: []cve.CVE{
			{ID: "CVE-2024-0001", Severity: cve.SeverityCritical, Package: "libssl", Version: "1.0"},
			{ID: "CVE-2024-0002", Severity: cve.SeverityHigh, Package: "openssh", Version: "8.0"},
		},
	}
}

func TestSaveScan(t *testing.T) {
	st := newTestStore(t)
	ctx := context.Background()
	r := sampleResult()

	if err := st.SaveScan(ctx, r); err != nil {
		t.Fatalf("SaveScan: %v", err)
	}

	// duplicate ignored
	if err := st.SaveScan(ctx, r); err != nil {
		t.Fatalf("SaveScan duplicate: %v", err)
	}
}

func TestListScans(t *testing.T) {
	st := newTestStore(t)
	ctx := context.Background()
	r := sampleResult()

	if err := st.SaveScan(ctx, r); err != nil {
		t.Fatalf("SaveScan: %v", err)
	}

	scans, err := st.ListScans(ctx, 10)
	if err != nil {
		t.Fatalf("ListScans: %v", err)
	}
	if len(scans) != 1 {
		t.Fatalf("expected 1 scan, got %d", len(scans))
	}
	if scans[0].ScanID != r.ScanID {
		t.Errorf("scan_id mismatch: got %q", scans[0].ScanID)
	}
	if scans[0].Critical != 1 || scans[0].High != 1 {
		t.Errorf("severity counts wrong: c=%d h=%d", scans[0].Critical, scans[0].High)
	}
}

func TestAlertDedup(t *testing.T) {
	st := newTestStore(t)
	ctx := context.Background()
	const (
		cveID = "CVE-2024-0001"
		host  = "testhost"
	)

	sent, err := st.IsAlertSent(ctx, cveID, host)
	if err != nil {
		t.Fatalf("IsAlertSent: %v", err)
	}
	if sent {
		t.Fatal("expected not sent yet")
	}

	if err := st.MarkAlertSent(ctx, cveID, host); err != nil {
		t.Fatalf("MarkAlertSent: %v", err)
	}

	sent, err = st.IsAlertSent(ctx, cveID, host)
	if err != nil {
		t.Fatalf("IsAlertSent after mark: %v", err)
	}
	if !sent {
		t.Fatal("expected alert marked as sent")
	}

	// duplicate mark ignored
	if err := st.MarkAlertSent(ctx, cveID, host); err != nil {
		t.Fatalf("MarkAlertSent duplicate: %v", err)
	}
}

func TestListScans_CVEsRoundtrip(t *testing.T) {
	st := newTestStore(t)
	ctx := context.Background()
	r := sampleResult()

	_ = st.SaveScan(ctx, r)
	scans, _ := st.ListScans(ctx, 10)

	if len(scans[0].CVEs) != 2 {
		t.Errorf("expected 2 CVEs, got %d", len(scans[0].CVEs))
	}
	if scans[0].CVEs[0].ID != "CVE-2024-0001" {
		t.Errorf("CVE ID mismatch: %q", scans[0].CVEs[0].ID)
	}
}
