// Package store provides SQLite-backed scan history for VASCA.
// Prevents duplicate CVE alerts across periodic scans.
// Source: VASCA v1 | License: Apache-2.0 | Usage: internal only
package store

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"time"

	_ "modernc.org/sqlite" // driver: "sqlite"

	"vasca/pkg/cve"
)

const schema = `
CREATE TABLE IF NOT EXISTS tbl_scans (
	scan_id      TEXT PRIMARY KEY,
	host         TEXT NOT NULL,
	started_at   TEXT NOT NULL,
	finished_at  TEXT NOT NULL,
	duration_sec REAL NOT NULL DEFAULT 0,
	total        INTEGER NOT NULL DEFAULT 0,
	critical     INTEGER NOT NULL DEFAULT 0,
	high         INTEGER NOT NULL DEFAULT 0,
	medium       INTEGER NOT NULL DEFAULT 0,
	low          INTEGER NOT NULL DEFAULT 0,
	cves_json    TEXT
);
CREATE TABLE IF NOT EXISTS tbl_alert_sent (
	cve_id  TEXT NOT NULL,
	host    TEXT NOT NULL,
	sent_at TEXT NOT NULL,
	PRIMARY KEY (cve_id, host)
);
`

// Store wraps a SQLite database for scan history and alert dedup.
type Store struct {
	db *sql.DB
}

// Open opens (or creates) the SQLite database at path.
// Use ":memory:" for tests.
func Open(path string) (*Store, error) {
	db, err := sql.Open("sqlite", path)
	if err != nil {
		return nil, fmt.Errorf("store open: %w", err)
	}
	if _, err := db.Exec(schema); err != nil {
		db.Close()
		return nil, fmt.Errorf("store schema: %w", err)
	}
	return &Store{db: db}, nil
}

// Close closes the underlying database.
func (s *Store) Close() error { return s.db.Close() }

// SaveScan persists a ScanResult. Duplicate scan_id is silently ignored.
func (s *Store) SaveScan(ctx context.Context, r *cve.ScanResult) error {
	cvesJSON, _ := json.Marshal(r.CVEs)
	_, err := s.db.ExecContext(ctx, `
		INSERT OR IGNORE INTO tbl_scans
		  (scan_id, host, started_at, finished_at, duration_sec,
		   total, critical, high, medium, low, cves_json)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		r.ScanID, r.Host,
		r.StartedAt.UTC().Format(time.RFC3339),
		r.FinishedAt.UTC().Format(time.RFC3339),
		r.DurationSec,
		r.Total, r.Critical, r.High, r.Medium, r.Low,
		string(cvesJSON),
	)
	return err
}

// IsAlertSent reports whether an alert for cveID on host was already sent.
func (s *Store) IsAlertSent(ctx context.Context, cveID, host string) (bool, error) {
	var count int
	err := s.db.QueryRowContext(ctx,
		`SELECT COUNT(*) FROM tbl_alert_sent WHERE cve_id=? AND host=?`,
		cveID, host).Scan(&count)
	return count > 0, err
}

// MarkAlertSent records that an alert was sent for cveID on host.
func (s *Store) MarkAlertSent(ctx context.Context, cveID, host string) error {
	_, err := s.db.ExecContext(ctx,
		`INSERT OR IGNORE INTO tbl_alert_sent (cve_id, host, sent_at) VALUES (?, ?, ?)`,
		cveID, host, time.Now().UTC().Format(time.RFC3339))
	return err
}

// ListScans returns the most recent scans up to limit.
func (s *Store) ListScans(ctx context.Context, limit int) ([]*cve.ScanResult, error) {
	rows, err := s.db.QueryContext(ctx, `
		SELECT scan_id, host, started_at, finished_at, duration_sec,
		       total, critical, high, medium, low, cves_json
		FROM tbl_scans ORDER BY started_at DESC LIMIT ?`, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var results []*cve.ScanResult
	for rows.Next() {
		var (
			r         cve.ScanResult
			startedAt string
			finAt     string
			cvesJSON  string
		)
		if err := rows.Scan(
			&r.ScanID, &r.Host, &startedAt, &finAt, &r.DurationSec,
			&r.Total, &r.Critical, &r.High, &r.Medium, &r.Low, &cvesJSON,
		); err != nil {
			return nil, err
		}
		r.StartedAt, _ = time.Parse(time.RFC3339, startedAt)
		r.FinishedAt, _ = time.Parse(time.RFC3339, finAt)
		_ = json.Unmarshal([]byte(cvesJSON), &r.CVEs)
		results = append(results, &r)
	}
	return results, rows.Err()
}
