// Package notifier sends VASCA scan results to SeCuardian API and Slack.
// Source: VASCA v1 | License: Apache-2.0 | Usage: internal only
package notifier

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"vasca/pkg/cve"
)

// Config holds notifier connection settings (injected from CLI flags / env).
type Config struct {
	SecuardianURL   string // e.g. http://localhost:8200
	SecuardianToken string // Bearer token for /api/vasca/scan-results
	SlackWebhookURL string // optional Slack incoming webhook
}

// Send posts the scan result to SeCuardian and optionally Slack.
// Only fires if Critical or High CVEs exist.
func Send(ctx context.Context, cfg Config, result *cve.ScanResult) error {
	if cfg.SecuardianURL != "" {
		if err := sendToSecuardian(ctx, cfg, result); err != nil {
			return fmt.Errorf("secuardian notify: %w", err)
		}
	}
	if cfg.SlackWebhookURL != "" && (result.Critical > 0 || result.High > 0) {
		if err := sendToSlack(ctx, cfg.SlackWebhookURL, result); err != nil {
			return fmt.Errorf("slack notify: %w", err)
		}
	}
	return nil
}

func sendToSecuardian(ctx context.Context, cfg Config, result *cve.ScanResult) error {
	body, err := json.Marshal(result)
	if err != nil {
		return err
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost,
		cfg.SecuardianURL+"/api/vasca/scan-results", bytes.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")
	if cfg.SecuardianToken != "" {
		req.Header.Set("Authorization", "Bearer "+cfg.SecuardianToken)
	}

	client := &http.Client{Timeout: 30 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode >= 400 {
		return fmt.Errorf("secuardian API error: %d", resp.StatusCode)
	}
	return nil
}

func sendToSlack(ctx context.Context, webhookURL string, result *cve.ScanResult) error {
	payload := map[string]string{
		"text": fmt.Sprintf(":rotating_light: VASCA Alert — %s\nCRITICAL=%d HIGH=%d HOST=%s",
			result.ScanID, result.Critical, result.High, result.Host),
	}
	body, _ := json.Marshal(payload)

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, webhookURL, bytes.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{Timeout: 10 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	return nil
}
