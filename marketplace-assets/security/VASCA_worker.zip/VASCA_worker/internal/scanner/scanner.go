// Package scanner provides CVE scanning via grype.
// Source: VASCA v1 | License: Apache-2.0 | Usage: internal only
package scanner

import (
	"context"
	"encoding/json"
	"fmt"
	"os/exec"
	"time"

	"vasca/pkg/cve"
)

// grypeMatch mirrors grype JSON output structure (minimal fields).
type grypeMatch struct {
	Vulnerability struct {
		ID          string   `json:"id"`
		Severity    string   `json:"severity"`
		CVSS        []struct{ Metrics struct{ BaseScore float64 } } `json:"cvss"`
		Description string   `json:"description"`
		URLs        []string `json:"urls"`
	} `json:"vulnerability"`
	Artifact struct {
		Name    string `json:"name"`
		Version string `json:"version"`
	} `json:"artifact"`
	RelatedVulnerabilities []struct {
		Fix struct{ Versions []string } `json:"fix"`
	} `json:"relatedVulnerabilities"`
}

type grypeOutput struct {
	Matches []grypeMatch `json:"matches"`
}

// ScanHost runs grype against the host filesystem and returns a ScanResult.
// Requires grype binary on PATH. Context timeout: 15 minutes recommended.
func ScanHost(ctx context.Context, host string) (*cve.ScanResult, error) {
	started := time.Now()

	out, err := runGrype(ctx, "dir:/")
	if err != nil {
		return nil, fmt.Errorf("grype scan failed: %w", err)
	}

	result := parseGrypeOutput(out, host, started)
	return result, nil
}

// runGrype executes grype with JSON output and returns raw bytes.
func runGrype(ctx context.Context, target string) ([]byte, error) {
	cmd := exec.CommandContext(ctx, "grype", target, "--output", "json", "--quiet")
	return cmd.Output()
}

// parseGrypeOutput converts raw grype JSON into a ScanResult.
func parseGrypeOutput(data []byte, host string, started time.Time) *cve.ScanResult {
	var raw grypeOutput
	_ = json.Unmarshal(data, &raw)

	finished := time.Now()
	result := &cve.ScanResult{
		ScanID:      fmt.Sprintf("vasca-%d", started.Unix()),
		Host:        host,
		StartedAt:   started,
		FinishedAt:  finished,
		DurationSec: finished.Sub(started).Seconds(),
	}

	for _, m := range raw.Matches {
		sev := cve.Severity(m.Vulnerability.Severity)
		var cvss float64
		if len(m.Vulnerability.CVSS) > 0 {
			cvss = m.Vulnerability.CVSS[0].Metrics.BaseScore
		}
		var fixedIn string
		if len(m.RelatedVulnerabilities) > 0 && len(m.RelatedVulnerabilities[0].Fix.Versions) > 0 {
			fixedIn = m.RelatedVulnerabilities[0].Fix.Versions[0]
		}

		finding := cve.CVE{
			ID:          m.Vulnerability.ID,
			Severity:    sev,
			CVSS:        cvss,
			Package:     m.Artifact.Name,
			Version:     m.Artifact.Version,
			FixedIn:     fixedIn,
			Description: m.Vulnerability.Description,
			URLs:        m.Vulnerability.URLs,
		}
		result.CVEs = append(result.CVEs, finding)
		result.Total++
		switch sev {
		case cve.SeverityCritical:
			result.Critical++
		case cve.SeverityHigh:
			result.High++
		case cve.SeverityMedium:
			result.Medium++
		case cve.SeverityLow:
			result.Low++
		}
	}
	return result
}
