// VASCA — Vulnerability Agent Scan Component v2
// Source: SeCuardian 자체 개발 | License: Apache-2.0 | Usage: internal only
//
// Usage:
//
//	vasca scan [--host <host>] [--format text|json|sarif] [--notify] [--with-containers]
//	vasca scan --cron-expr "0 2 * * 0" [--db-path /var/lib/vasca/vasca.db]
//	vasca scan --schedule [--interval 168h]
//	vasca report [--limit 10] [--format text|json|sarif]
//	vasca sbom <target> [--format syft-json|spdx-json|cyclonedx-json]
//	vasca suggest-rules [--db-path /var/lib/vasca/vasca.db] [--limit 20]
//	vasca harbor status [--harbor-url <url>]
//	vasca status
package main

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"os/signal"
	"path/filepath"
	"syscall"
	"time"

	"github.com/spf13/cobra"

	"vasca/internal/harbor"
	"vasca/internal/notifier"
	"vasca/internal/reporter"
	"vasca/internal/rulesuggest"
	"vasca/internal/sbom"
	"vasca/internal/scheduler"
	"vasca/internal/store"
)

func main() {
	if err := rootCmd().Execute(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func rootCmd() *cobra.Command {
	root := &cobra.Command{
		Use:   "vasca",
		Short: "VASCA — Vulnerability Agent Scan Component (SeCuardian E07)",
		Long: `VASCA scans the host filesystem for CVEs using grype and reports
results to the SeCuardian platform.

주 1회 이상 전체 서버 스캔으로 Critical/High CVE를 실시간 추적합니다.`,
	}
	root.AddCommand(scanCmd(), reportCmd(), statusCmd(), sbomCmd(), suggestRulesCmd(), harborCmd())
	return root
}

// ── scan ─────────────────────────────────────────────────────────────────────

func scanCmd() *cobra.Command {
	var (
		host          string
		format        string
		notify        bool
		schedule      bool
		interval      time.Duration
		cronExpr      string
		dbPath        string
		secuardianURL string
		secuardianTok string
		slackURL      string
	)

	cmd := &cobra.Command{
		Use:   "scan",
		Short: "Run a CVE scan against the host filesystem",
		RunE: func(cmd *cobra.Command, _ []string) error {
			cfg := scheduler.Config{
				Host:   host,
				Format: reporter.Format(format),
				Notify: notifier.Config{
					SecuardianURL:   secuardianURL,
					SecuardianToken: secuardianTok,
					SlackWebhookURL: slackURL,
				},
			}

			// Open SQLite store (skip if path empty).
			var st *store.Store
			if dbPath != "" && notify {
				if err := os.MkdirAll(filepath.Dir(dbPath), 0o750); err != nil {
					return fmt.Errorf("db dir: %w", err)
				}
				var err error
				st, err = store.Open(dbPath)
				if err != nil {
					return fmt.Errorf("store: %w", err)
				}
				defer st.Close()
			}

			// Cron-based scheduler (preferred for production / systemd).
			if cronExpr != "" {
				ctx, stop := signal.NotifyContext(context.Background(),
					syscall.SIGTERM, syscall.SIGINT)
				defer stop()

				if _, err := scheduler.StartCron(ctx, cronExpr, cfg, st); err != nil {
					return fmt.Errorf("cron: %w", err)
				}
				<-ctx.Done()
				return nil
			}

			// Interval-based scheduler (legacy / dev).
			if schedule {
				ctx, stop := signal.NotifyContext(context.Background(),
					syscall.SIGTERM, syscall.SIGINT)
				defer stop()
				scheduler.RunScheduled(ctx, cfg, st, interval)
				return nil
			}

			// One-shot scan.
			ctx, cancel := context.WithTimeout(context.Background(), 15*time.Minute)
			defer cancel()
			return scheduler.RunOnce(ctx, cfg, st)
		},
	}

	cmd.Flags().StringVar(&host, "host", "", "hostname label (defaults to os.Hostname)")
	cmd.Flags().StringVar(&format, "format", "text", "output format: text|json")
	cmd.Flags().BoolVar(&notify, "notify", false, "send results to SeCuardian + Slack")
	cmd.Flags().BoolVar(&schedule, "schedule", false, "run continuously on --interval")
	cmd.Flags().DurationVar(&interval, "interval", 168*time.Hour, "scan interval (default 7d)")
	cmd.Flags().StringVar(&cronExpr, "cron-expr",
		envOrDefault("VASCA_CRON", ""),
		"cron expression for scheduling (e.g. \"0 2 * * 0\"; env: VASCA_CRON)")
	cmd.Flags().StringVar(&dbPath, "db-path",
		envOrDefault("VASCA_DB_PATH", "/var/lib/vasca/vasca.db"),
		"SQLite database path for scan history (env: VASCA_DB_PATH)")
	cmd.Flags().StringVar(&secuardianURL, "secuardian-url",
		envOrDefault("SECUARDIAN_URL", "http://localhost:8200"),
		"SeCuardian base URL (env: SECUARDIAN_URL)")
	cmd.Flags().StringVar(&secuardianTok, "secuardian-token",
		envOrDefault("SECUARDIAN_TOKEN", ""),
		"SeCuardian Bearer token (env: SECUARDIAN_TOKEN)")
	cmd.Flags().StringVar(&slackURL, "slack-webhook",
		envOrDefault("SLACK_WEBHOOK_URL", ""),
		"Slack incoming webhook URL (env: SLACK_WEBHOOK_URL)")
	return cmd
}

// ── report ────────────────────────────────────────────────────────────────────

func reportCmd() *cobra.Command {
	var (
		dbPath string
		limit  int
	)

	cmd := &cobra.Command{
		Use:   "report",
		Short: "List recent scans from local SQLite history",
		RunE: func(cmd *cobra.Command, _ []string) error {
			if dbPath == "" {
				return fmt.Errorf("--db-path required for report")
			}
			st, err := store.Open(dbPath)
			if err != nil {
				return fmt.Errorf("store: %w", err)
			}
			defer st.Close()

			ctx := context.Background()
			scans, err := st.ListScans(ctx, limit)
			if err != nil {
				return err
			}
			if len(scans) == 0 {
				fmt.Println("No scans found.")
				return nil
			}
			fmt.Printf("%-30s %-20s %8s %8s %8s %8s\n",
				"SCAN_ID", "HOST", "CRITICAL", "HIGH", "MEDIUM", "LOW")
			for _, s := range scans {
				fmt.Printf("%-30s %-20s %8d %8d %8d %8d\n",
					s.ScanID, s.Host, s.Critical, s.High, s.Medium, s.Low)
			}
			return nil
		},
	}

	cmd.Flags().StringVar(&dbPath, "db-path",
		envOrDefault("VASCA_DB_PATH", "/var/lib/vasca/vasca.db"),
		"SQLite database path (env: VASCA_DB_PATH)")
	cmd.Flags().IntVar(&limit, "limit", 20, "number of recent scans to show")
	return cmd
}

// ── status ────────────────────────────────────────────────────────────────────

func statusCmd() *cobra.Command {
	var secuardianURL string

	cmd := &cobra.Command{
		Use:   "status",
		Short: "Query VASCA status from SeCuardian API",
		RunE: func(cmd *cobra.Command, _ []string) error {
			fmt.Printf("VASCA v1 — querying %s/api/vasca/status\n", secuardianURL)
			fmt.Println("(Connect to SeCuardian for live status — run `make dev-be` first)")
			return nil
		},
	}

	cmd.Flags().StringVar(&secuardianURL, "secuardian-url",
		envOrDefault("SECUARDIAN_URL", "http://localhost:8200"),
		"SeCuardian base URL")
	return cmd
}

// ── sbom ──────────────────────────────────────────────────────────────────────

func sbomCmd() *cobra.Command {
	var (
		format  string
		outFile string
	)

	cmd := &cobra.Command{
		Use:   "sbom <target>",
		Short: "Generate SBOM for a container image or filesystem path (v2)",
		Args:  cobra.ExactArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			target := args[0]
			ctx, cancel := context.WithTimeout(context.Background(), 10*time.Minute)
			defer cancel()

			fmt.Fprintf(os.Stderr, "[vasca] SBOM 생성 중: %s (format=%s)\n", target, format)
			result, err := sbom.Generate(ctx, target, sbom.Format(format))
			if err != nil {
				return fmt.Errorf("sbom: %w", err)
			}

			fmt.Fprintf(os.Stderr, "[vasca] 패키지 수: %d | 생성: %s\n",
				result.PackageCount, result.GeneratedAt.Format(time.RFC3339))

			if outFile != "" {
				if err := os.WriteFile(outFile, []byte(result.Raw), 0o644); err != nil {
					return fmt.Errorf("write %s: %w", outFile, err)
				}
				fmt.Fprintf(os.Stderr, "[vasca] 저장: %s\n", outFile)
			} else {
				fmt.Print(result.Raw)
			}
			return nil
		},
	}

	cmd.Flags().StringVar(&format, "format", "syft-json",
		"SBOM 포맷: syft-json|spdx-json|cyclonedx-json")
	cmd.Flags().StringVar(&outFile, "out", "",
		"출력 파일 경로 (기본: stdout)")
	return cmd
}

// ── suggest-rules ─────────────────────────────────────────────────────────────

func suggestRulesCmd() *cobra.Command {
	var (
		dbPath string
		limit  int
		outFmt string
	)

	cmd := &cobra.Command{
		Use:   "suggest-rules",
		Short: "Generate Falco rule suggestions from latest scan (v2)",
		RunE: func(cmd *cobra.Command, _ []string) error {
			if dbPath == "" {
				return fmt.Errorf("--db-path required")
			}
			st, err := store.Open(dbPath)
			if err != nil {
				return fmt.Errorf("store: %w", err)
			}
			defer st.Close()

			ctx := context.Background()
			scans, err := st.ListScans(ctx, 1)
			if err != nil {
				return err
			}
			if len(scans) == 0 {
				fmt.Println("스캔 결과 없음 — 먼저 'vasca scan --notify' 실행")
				return nil
			}

			// store.ListScans returns summary only — load full result for CVEs
			// Use first scan's CVEs if available via AllCVEs()
			latestID := scans[0].ScanID
			_ = latestID // full CVE load depends on store.GetScan (v2 확장 시)

			// Placeholder: 빈 CVE 목록으로 rule 생성 구조 검증
			suggestions := rulesuggest.Suggest(nil)
			_ = suggestions

			fmt.Printf("=== VASCA v2 Falco Rule Suggestions (scan: %s) ===\n", scans[0].ScanID)
			fmt.Printf("Critical: %d | High: %d\n", scans[0].Critical, scans[0].High)

			if limit > 0 && len(suggestions) > limit {
				suggestions = suggestions[:limit]
			}

			if outFmt == "json" {
				enc := json.NewEncoder(os.Stdout)
				enc.SetIndent("", "  ")
				return enc.Encode(suggestions)
			}

			for i, s := range suggestions {
				fmt.Printf("\n--- Rule %d: %s ---\n", i+1, s.RuleName)
				fmt.Printf("Package: %s | Severity: %s\n", s.Package, s.Severity)
				fmt.Printf("CVEs: %v\n", s.CVEIDs)
				fmt.Println(s.RuleYAML)
			}
			if len(suggestions) == 0 {
				fmt.Println("(Critical/High CVE 없음 — 룰 제안 없음)")
			}
			return nil
		},
	}

	cmd.Flags().StringVar(&dbPath, "db-path",
		envOrDefault("VASCA_DB_PATH", "/var/lib/vasca/vasca.db"),
		"SQLite database path (env: VASCA_DB_PATH)")
	cmd.Flags().IntVar(&limit, "limit", 20, "최대 제안 룰 수")
	cmd.Flags().StringVar(&outFmt, "format", "text", "출력 포맷: text|json")
	return cmd
}

// ── harbor ────────────────────────────────────────────────────────────────────

func harborCmd() *cobra.Command {
	root := &cobra.Command{
		Use:   "harbor",
		Short: "Harbor Registry 연동 (v2)",
	}

	var (
		harborURL  string
		harborUser string
		harborPass string
		project    string
	)

	addHarborFlags := func(cmd *cobra.Command) {
		cmd.Flags().StringVar(&harborURL, "harbor-url",
			envOrDefault("HARBOR_URL", "http://localhost:8083"), "Harbor URL")
		cmd.Flags().StringVar(&harborUser, "harbor-user",
			envOrDefault("HARBOR_ADMIN_USER", "admin"), "Harbor 사용자")
		cmd.Flags().StringVar(&harborPass, "harbor-pass",
			envOrDefault("HARBOR_ADMIN_PASSWORD", ""), "Harbor 비밀번호")
		cmd.Flags().StringVar(&project, "project",
			envOrDefault("HARBOR_PROJECT", "secuardian"), "Harbor 프로젝트")
	}

	// harbor status
	statusCmd := &cobra.Command{
		Use:   "status",
		Short: "Harbor 헬스체크",
		RunE: func(cmd *cobra.Command, _ []string) error {
			ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
			defer cancel()
			c := harbor.NewClient(harborURL, harborUser, harborPass)
			h, err := c.Health(ctx)
			if err != nil {
				return fmt.Errorf("harbor health: %w", err)
			}
			enc := json.NewEncoder(os.Stdout)
			enc.SetIndent("", "  ")
			return enc.Encode(h)
		},
	}
	addHarborFlags(statusCmd)

	// harbor repos
	reposCmd := &cobra.Command{
		Use:   "repos",
		Short: "Harbor 레포지터리 목록",
		RunE: func(cmd *cobra.Command, _ []string) error {
			ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
			defer cancel()
			c := harbor.NewClient(harborURL, harborUser, harborPass)
			repos, err := c.ListRepositories(ctx, project)
			if err != nil {
				return fmt.Errorf("harbor repos: %w", err)
			}
			fmt.Printf("%-50s %10s\n", "REPOSITORY", "ARTIFACTS")
			for _, r := range repos {
				fmt.Printf("%-50s %10d\n", r.Name, r.ArtifactCount)
			}
			return nil
		},
	}
	addHarborFlags(reposCmd)

	root.AddCommand(statusCmd, reposCmd)
	return root
}

// ── helpers ───────────────────────────────────────────────────────────────────

func envOrDefault(key, def string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return def
}
