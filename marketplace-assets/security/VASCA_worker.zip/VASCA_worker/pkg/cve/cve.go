// Package cve defines CVE data models for VASCA.
// Source: VASCA v1 (SeCuardian 자체 개발) | License: Apache-2.0 | Usage: internal only
package cve

import "time"

// Severity represents CVE severity level.
type Severity string

const (
	SeverityCritical Severity = "CRITICAL"
	SeverityHigh     Severity = "HIGH"
	SeverityMedium   Severity = "MEDIUM"
	SeverityLow      Severity = "LOW"
	SeverityNone     Severity = "NONE"
	SeverityUnknown  Severity = "UNKNOWN"
)

// CVE holds a single vulnerability finding.
type CVE struct {
	ID          string   `json:"id"`           // CVE-YYYY-NNNNN
	Severity    Severity `json:"severity"`
	CVSS        float64  `json:"cvss"`
	Package     string   `json:"package"`
	Version     string   `json:"version"`
	FixedIn     string   `json:"fixed_in"`
	Description string   `json:"description"`
	URLs        []string `json:"urls"`
}

// ScanResult holds the result of a single VASCA scan.
type ScanResult struct {
	ScanID      string    `json:"scan_id"`
	Host        string    `json:"host"`
	StartedAt   time.Time `json:"started_at"`
	FinishedAt  time.Time `json:"finished_at"`
	DurationSec float64   `json:"duration_sec"`
	Total       int       `json:"total"`
	Critical    int       `json:"critical"`
	High        int       `json:"high"`
	Medium      int       `json:"medium"`
	Low         int       `json:"low"`
	CVEs        []CVE     `json:"cves"`
}

// Summary returns a short human-readable status line.
func (r *ScanResult) Summary() string {
	return r.ScanID + ": CRITICAL=" + itoa(r.Critical) + " HIGH=" + itoa(r.High) +
		" MEDIUM=" + itoa(r.Medium) + " LOW=" + itoa(r.Low)
}

func itoa(n int) string {
	if n == 0 {
		return "0"
	}
	buf := make([]byte, 0, 10)
	for n > 0 {
		buf = append([]byte{byte('0' + n%10)}, buf...)
		n /= 10
	}
	return string(buf)
}
