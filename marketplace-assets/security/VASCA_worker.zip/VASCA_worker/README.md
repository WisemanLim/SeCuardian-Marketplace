# VASCA_worker — CVE 스캔 Worker (Go)

SeCuardian `vasca-cve` 에이전트의 실작업 worker 입니다. 스캔 대상 호스트(서버·PC·Edge
디바이스)에 설치되어 CVE 스캔(grype)·SBOM(syft)·Falco 룰 제안을 수행하고 결과를
SeCuardian 으로 전송합니다.
This is the worker for the SeCuardian `vasca-cve` agent. Install it on each scan-target
host; it performs CVE scans (grype), SBOM generation (syft), Falco rule suggestions, and
pushes results to SeCuardian.

- 버전 / Version: `VERSION` 파일 참조 (semver)
- 동봉 바이너리 / Bundled binary: `bin/vasca` (linux/amd64, CGO 미사용)
- 배포 패키지 / Package: `VASCA_worker.zip` — `make worker-package` (repo 루트)로 재생성

## 빠른 시작 / Quick start

```bash
# 동봉 바이너리 사용 (linux/amd64)
./bin/vasca scan --format text

# 소스 빌드 (Go 1.22+)
make build            # → bin/vasca

# systemd 상주 설치 (SeCuardian 저장소 루트에서, Linux/root)
sudo ./deploy/scripts/vasca_install.sh
```

## 주요 명령 / Commands

```bash
vasca scan  [--format text|json] [--notify --secuardian-url URL --secuardian-token TOK]
vasca scan  --schedule --interval 168h ...     # 주기 스캔
vasca sbom  <path> --format syft-json|spdx-json
vasca suggest-rules ...                        # Falco 룰 제안
vasca harbor status|repos                      # Harbor 연동
```

## SeCuardian 연동 / Wire-up

- worker → 서버: `--secuardian-url http://<server>:8200` + `--secuardian-token`
  (`POST /api/vasca/scan-results`, 서버 측 `VASCA_ENABLED=true` 필요)
- 서버 → worker 상태: `VASCA_AGENT_URL` (기본 `http://localhost:9310`)

상세 설치·운영 가이드는 에이전트에 내장된 `vasca-cve-worker-guide.md`
(`addon-agents/zip/vasca-cve/` 또는 배포 후 `addon-agents/deployed/vasca-cve/`)를 참조하세요.
