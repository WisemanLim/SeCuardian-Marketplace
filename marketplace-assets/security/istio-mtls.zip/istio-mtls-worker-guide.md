# Istio 서비스 메쉬 mTLS 모니터 — Worker 설치 가이드 / Worker Install Guide

> 이 에이전트는 외부 worker 가 기동되어 있어야 완전히 동작합니다. 미기동 시 우아하게 저하됩니다.
> This agent requires an external worker; it degrades gracefully when the worker is down.

---

## 1. Worker 개요

- **도구**: [Istio](https://istio.io/) (Apache-2.0) — istiod 컨트롤 플레인
- **역할**: K8s 서비스 메쉬 mTLS(PeerAuthentication STRICT)·AuthorizationPolicy 현황과 istiod 준비 상태를 조회합니다.
- **포트**: istiod `15014`(모니터링) / `8080`(`/ready`) — 클러스터 내부
- **에이전트 설정 방식**: 환경변수(`os.getenv`) — SeCuardian-Basic `.env.*` 또는 compose `environment` 에 선언

## 2. 환경변수 (`optional_env`)

| 변수 | 설명 | 기본값 |
|------|------|--------|
| `ISTIO_PILOT_URL` | istiod readiness URL | `http://istiod.istio-system:8080` |

## 3. 설치 (독립 설치 예시)

```bash
# 1) istioctl 설치 후 minimal 프로파일 (Cilium 이 L3/L4, Istio 는 L7 mTLS 담당)
curl -L https://istio.io/downloadIstio | ISTIO_VERSION=1.23.2 sh -
istioctl install --set profile=minimal -y
# 2) mesh-wide STRICT mTLS + AuthorizationPolicy
kubectl apply -f deploy/k8s/istio/peer-authentication.yaml
kubectl apply -f deploy/k8s/istio/authorization-policy.yaml
istioctl analyze
# 3) API 파드가 클러스터 밖이면 포트포워드
kubectl -n istio-system port-forward deploy/istiod 8080:8080
```

## 4. 에이전트 엔드포인트 (`/api/addon/istio-mtls`)

| 엔드포인트 | 설명 |
|-----------|------|
| `GET /status` | istiod `/ready` 결과 (UP/DOWN/UNREACHABLE) |
| `GET /mtls` | PeerAuthentication·AuthorizationPolicy 참조 |
| `GET /config` | 설치 프로파일·스크립트 참조 |

## 5. 미기동 시 동작

istiod 미접속 시 `/status` 는 `UNREACHABLE` 로 정상 응답(503 아님). K8s 외 환경에서는 참조 정보만 제공됩니다.

## 6. 확인

```bash
curl -s -H "Authorization: Bearer <token>" http://localhost:8200/api/addon/istio-mtls/status
```
