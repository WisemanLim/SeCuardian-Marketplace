"""istio-mtls — Istio 서비스 메쉬 mTLS 모니터 Addon (SeCuardian router_istio.py 이식).
# Source: SeCuardian | License: Apache-2.0 | Usage: internal only

마운트: /api/addon/istio-mtls
  GET /status  — service_mesh: 컨트롤 플레인 상태
  GET /mtls    — mTLS 정책 현황
  GET /config  — 설치 설정 참조

이식 노트: settings 비의존 — ISTIO_PILOT_URL env. ⚠️ from __future__ import annotations 금지.
"""
import os

import httpx
from fastapi import APIRouter, Depends

from app.core.deps import get_current_user

router = APIRouter(tags=["istio-mtls"])


def _pilot_url() -> str:
    return os.getenv("ISTIO_PILOT_URL", "http://istiod.istio-system:8080").rstrip("/")


@router.get("/status")
async def istio_status(_: dict = Depends(get_current_user)):
    """Istio 컨트롤 플레인 상태. Orchestrator intent: service_mesh (L4/L7)"""
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.get(f"{_pilot_url()}/ready")
        return {
            "istio_pilot_url": _pilot_url(),
            "status": "UP" if resp.is_success else "DOWN",
            "http_status": resp.status_code,
            "mtls_mode": "STRICT",
            "profile": "minimal",
        }
    except httpx.ConnectError:
        return {
            "istio_pilot_url": _pilot_url(),
            "status": "UNREACHABLE",
            "note": "K8s 환경에서만 동작 — deploy/scripts/istio_install.sh 참조",
        }


@router.get("/mtls")
async def mtls_status(_: dict = Depends(get_current_user)):
    """mTLS 정책 현황."""
    return {
        "peer_authentication": {"mode": "STRICT", "scope": "mesh-wide", "file": "deploy/k8s/istio/peer-authentication.yaml"},
        "authorization_policy": {"target": "secuardian", "allowed_namespaces": ["internal", "dmz"], "file": "deploy/k8s/istio/authorization-policy.yaml"},
        "verify_command": "istioctl analyze",
    }


@router.get("/config")
async def istio_config(_: dict = Depends(get_current_user)):
    """Istio 설치 설정 참조."""
    return {
        "version": "1.23.2",
        "profile": "minimal",
        "cni": "cilium",
        "role": "L7 서비스 인증 / mTLS (Cilium: L3/L4 담당)",
        "istio_pilot_url": _pilot_url(),
        "install_script": "deploy/scripts/istio_install.sh",
    }
